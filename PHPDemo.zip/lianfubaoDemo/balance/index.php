<?php
header("Content-type:text/html;charset=utf8");
require_once("../common/Config.php");
require_once("../utils/ServiceUtil.php");

// -----余额查询-----

// 请求参数
$arr["merId"] = Config::merId;
$arr["version"] = Config::version;

// 签名参数 data
$signArr["merId"] = Config::merId;
$signStr = ServiceUtil::get_sign($signArr)."&key=".Config::remitSignKey;
$signArr["sign"] = strtoupper(md5($signStr));

// 公钥加密
$publicKey = ServiceUtil::publicKeyStr(Config::remitPublicKey);
$data = ServiceUtil::publicEncrypt(json_encode($signArr), $publicKey);
$arr["data"] = $data;

// 发送请求
$result  = ServiceUtil::curlPost(Config::balanceUrl, json_encode($arr));

$resultArr = json_decode($result, true);
if($resultArr["code"]==200) { // 请求成功
    $resultData = $resultArr["data"];
    
    $merId = $resultData["merId"];
    $usableAmount = $resultData["usableAmount"];
    $frezeeAmount = $resultData["frezeeAmount"];
    
    // 验签参数
    $resSignArr["merId"] = Config::merId;
    $resSignArr["usableAmount"] = $usableAmount;
    $resSignArr["frezeeAmount"] = $frezeeAmount;
    
    ksort($resSignArr);
    
    $resSignStr = ServiceUtil::get_sign($resSignArr)."&key=".Config::remitSignKey;
    
    // 验签
    if(strcasecmp(md5($resSignStr), $resultData["sign"])==0) {
        
        echo("商户编号<b>[".$merId."]</b>余额信息:<br>");
        echo("可用余额: <b>".$usableAmount."元</b>, 冻结金额: <b>".$frezeeAmount."元</b><br>");
    } else {
        echo "signature fail";
    }
    
} else {
    echo $resultArr["message"];
}

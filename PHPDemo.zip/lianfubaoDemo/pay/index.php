<?php
header("Content-type:text/html;charset=utf8");
require_once("../common/Config.php");
require_once("../utils/ServiceUtil.php");

// ----支付下单请求----

// 请求参数
$arr["merId"] = Config::merId;
$arr["version"] = Config::version;

// 签名参数 data
$signArr["merOrderNo"] = $_POST["merOrderNo"];  // 商户订单号  date("YmdHis",time()).rand(1000,9999)
$signArr["amount"] = $_POST["amount"];   // 下单金额
$signArr["payType"] = "ebank"; // 支付类型 固定值：ebank
$signArr["businessType"] = 1;  // 订单类型 1（对私）2（对公）,固定值1
$signArr["notifyUrl"] = $_POST["notifyUrl"];  // 回调通知URL
$signArr["expireTime"] = $_POST["expireTime"];  // 过期时间（单位：分钟）
$signArr["bankCode"] = $_POST["bankCode"];  // 银行编号
$signArr["orderIp"] = ServiceUtil::getIp();  // 下单请求IP
$signArr["submitTime"] = ServiceUtil::msectime();  // 提交时间 时间戳（毫秒）

ksort($signArr);

$signStr = ServiceUtil::get_sign($signArr)."&key=".Config::paySignKey;
$signArr["returnViewUrl"] = $_POST["returnViewUrl"];  // 回显地址
$signArr["remarks"] = $_POST["remarks"];  // 备注
$signArr["sign"] = strtoupper(md5($signStr));

// 公钥加密
$publicKey = ServiceUtil::publicKeyStr(Config::payPublicKey);
$data = ServiceUtil::publicEncrypt(json_encode($signArr), $publicKey);
$arr["data"] = $data;

// 发送请求
$result = ServiceUtil::curlPost(Config::payUrl, json_encode($arr));

$resultArr = json_decode($result, true);
if($resultArr) {
    if($resultArr["code"]==200){
        $payUrl = $resultArr["data"]["payUrl"];
        header("location:".$payUrl);
    } else {
        echo $resultArr["message"]."<br>";
    }
} else {
    echo "fail";
}
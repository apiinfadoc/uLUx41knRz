<?php
header("Content-type:text/html;charset=utf8");
require_once("../common/Config.php");
require_once("../utils/ServiceUtil.php");

// ---支付订单查询---

// 请求参数
$arr["merId"] = Config::merId;
$arr["version"] = Config::version;

// 签名参数 data
$signArr["merOrderNo"] = $_POST["merOrderNo"];
$signArr["submitTime"] = ServiceUtil::msectime();

ksort($signArr);

$signStr = ServiceUtil::get_sign($signArr)."&key=".Config::paySignKey;

$signArr["sign"] = strtoupper(md5($signStr));

// 公钥加密
$publicKey = ServiceUtil::publicKeyStr(Config::payPublicKey);
$data = ServiceUtil::publicEncrypt(json_encode($signArr), $publicKey);
$arr["data"] = $data;

// 发送请求
$result = ServiceUtil::curlPost(Config::payQueryUrl, json_encode($arr));
$resultArr = json_decode($result, true);
if($resultArr) {
    if($resultArr["code"] == 200) {
        $resultData = $resultArr["data"];
        $merOrderNo = $resultData["merOrderNo"];
        $amount = $resultData["amount"];
        $orderState = $resultData["orderState"];
        $orderNo = $resultData["orderNo"];
        
        // 验签参数
        $resSignArr["merOrderNo"] = $merOrderNo;
        $resSignArr["orderState"] = $orderState;
        $resSignArr["orderNo"] = $orderNo;
        $resSignArr["amount"] = $amount;
        $resSignArr["merId"] = Config::merId;
        
        ksort($resSignArr);
        
        $resSignStr = ServiceUtil::get_sign($resSignArr)."&key=".Config::paySignKey;
        // 验签
        if(strcasecmp(md5($resSignStr), $resultData["sign"])==0) {
            
            $stateMsg = $orderState == 1 ? "成功" : ($orderState == 2 ? "失败" : "处理中");
            echo("订单<b>[".$merOrderNo."]</b>信息:<br>");
            echo("支付金额: <b>".$amount."元</b>, 平台订单号: <b>".$orderNo."</b>, 订单状态: <b>".$stateMsg."<b><br>");
        } else {
            echo "signature fail";
        }
    } else {
        echo $resultArr["message"]."<br>";
    }
    
} else {
    echo "fail";
}

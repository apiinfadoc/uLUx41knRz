<?php
header("Content-type:text/html;charset=utf8");
require_once("../common/Config.php");
require_once("../utils/ServiceUtil.php");

// ----支付下单回调通知----

// 回调通知数据
$post = file_get_contents("php://input");
$resultArr = json_decode($post, true);
$data = $resultArr["data"];

// 私钥解密
$privateKey = ServiceUtil::privateKeyStr(Config::payPrivateKey);
$signData = ServiceUtil::privateDecrypt($data, $privateKey);

$signArr = json_decode($signData, true);
if($signArr) {
    // 验签参数
    $orderState = $signArr["orderState"];
    $arr["merOrderNo"] = $signArr["merOrderNo"];
    $arr["orderState"] = $orderState;
    $arr["orderNo"] = $signArr["orderNo"];
    $arr["amount"] = $signArr["amount"];
    
    ksort($arr);
    
    $signStr = ServiceUtil::get_sign($arr)."&key=".Config::paySignKey;
    // 验签
    // 验签成功后，回调业务处理，业务结束后，返回success通知回调成功；否则返回其他结果
    if(strcasecmp(md5($signStr), $signArr["sign"])==0) {
        // TODO 业务逻辑
        // 1:成功  2:失败
        if($orderState == 1 || $orderState == 2) {
            
            echo "success";
        } else {  // 订单未处理
            
            echo "fail";
        }
    } else {
        
        echo "fail";
    }
}

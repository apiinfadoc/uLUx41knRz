<?php
header("Content-type:text/html;charset=utf8");
require_once("../common/Config.php");
require_once("../utils/ServiceUtil.php");

// ---代付下单---

// 请求参数
$arr["merId"] = Config::merId;
$arr["version"] = Config::version;

// 签名参数 data
$signArr["merOrderNo"] = $_POST["merOrderNo"];  // 商户订单号
$signArr["amount"] = $_POST["amount"];  // 下发金额：元
$signArr["submitTime"] = ServiceUtil::msectime();  // 提交时间：时间戳（毫秒）
$signArr["notifyUrl"] = $_POST["notifyUrl"];  // 回调通知URL
$signArr["bankCode"] = $_POST["bankCode"];  // 收款银行编号
$signArr["bankAccountNo"] = $_POST["bankAccountNo"];  // 收款银行账号
$signArr["bankAccountName"] = $_POST["bankAccountName"];  // 收款人名字

ksort($signArr);

$signStr = ServiceUtil::get_sign($signArr)."&key=".Config::remitSignKey;
$signArr["bankBranchName"] = $_POST["bankBranchName"];  // 分行名称
$signArr["remarks"] = $_POST["remarks"];  // 备注
$signArr["sign"] = md5($signStr);

// 公钥加密
$publicKey = ServiceUtil::publicKeyStr(Config::remitPublicKey);
$data = ServiceUtil::publicEncrypt(json_encode($signArr), $publicKey);
$arr["data"] = $data;

// 发送请求
$result = ServiceUtil::curlPost(Config::remitUrl, json_encode($arr));
$resultArr = json_decode($result, true);
if($resultArr) {
    if($resultArr["code"] == 200) { // 成功的业务处理
        
        echo "success";
    } else {
        echo $resultArr["message"]."<br>";
    }
} else {
    echo "fail";
}
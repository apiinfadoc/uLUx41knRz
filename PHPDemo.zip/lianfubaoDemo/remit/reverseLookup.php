<?php
header("Content-type:text/html;charset=utf8");
require_once("../common/Config.php");
require_once("../utils/ServiceUtil.php");

// ---代付反查---

// 回调数据
$post = file_get_contents("php://input");
$resultArr = json_decode($post, true);

$merId = Config::merId;
$merOrderNo = $resultArr["merOrderNo"];
$submitTime = $resultArr["submitTime"];

$signArr["merId"] = $merId;  // 商户编号
$signArr["merOrderNo"] = $merOrderNo;  // 商户订单号
$signArr["bankAccountNo"] = $resultArr["bankAccountNo"];  // 银行卡号
$signArr["amount"] = $resultArr["amount"];  // 代付金额
$signArr["submitTime"] = $submitTime;  // 提交时间 时间戳（毫秒）

ksort($signArr);

$code = 9999;
$msg = "系统未知异常";

$signStr = ServiceUtil::get_sign($signArr)."&key=".Config::remitSignKey;
// 验签
if(strcasecmp(md5($signStr), $resultArr["sign"])==0) { // 验签成功
    // TODO 业务逻辑, 返回对应的code和msg
    
    // 0:成功  1002:订单不存在  1003:银行卡号不匹配  1004:金额不匹配
    $code = 1002;
    $msg = "订单不存在";
    
} else { // 验签失败
    $code = 1001;
    $msg = "签名错误";
}

// 响应参数
$responseArr["merId"] = $merId;
$responseArr["merOrderNo"] = $merOrderNo;
$responseArr["submitTime"] = $submitTime;
$responseArr["code"] = $code;
$responseArr["message"] = $msg;

ksort($responseArr);

$signStr = ServiceUtil::get_sign($responseArr)."&key=".Config::remitSignKey;
$responseArr["sign"] = strtoupper(md5($signStr));

echo ServiceUtil::get_sign($responseArr);
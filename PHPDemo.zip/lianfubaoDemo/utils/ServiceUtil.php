<?php
header("Content-type:text/html;charset=utf8");

class ServiceUtil
{

    /**
     * 数组转为url字符串 过滤掉空值字段
     * $arr 数组
     */
    static function get_sign($arr)
    {
        $signmd5 = "";
        foreach ($arr as $x => $x_value) {
            if (! $x_value == "" || $x_value == 0) {
                if ($signmd5 == "") {
                    $signmd5 = $signmd5 . $x . '=' . $x_value;
                } else {
                    $signmd5 = $signmd5 . '&' . $x . '=' . $x_value;
                }
            }
        }
        return $signmd5;
    }

    /**
     * 拼接公钥字符串
     * @param $publicStr
     * @return string
     */
    static function publicKeyStr($publicStr)
    {
        // 公钥
        $public_key = "-----BEGIN PUBLIC KEY-----\r\n";
        foreach (str_split($publicStr, 64) as $str) {
            $public_key .= $str . "\r\n";
        }
        $public_key .= "-----END PUBLIC KEY-----";
        
        return $public_key;
    }

    /**
     * 拼接私钥字符串
     * @param $privatekey
     * @return string
     */
    static function privateKeyStr($privatekey)
    {
        $private_key = "-----BEGIN PRIVATE KEY-----\r\n";
        foreach (str_split($privatekey, 64) as $str) {
            $private_key .= $str . "\r\n";
        }
        $private_key .= "-----END PRIVATE KEY-----";
        
        return $private_key;
    }

    /**
     * 公钥加密
     * @param $data
     * @param $publicKey
     * @return void|$crypto
     */
    static function publicEncrypt($data, $publicKey)
    {

        try {
            $crypto = "";
            $res = openssl_pkey_get_public($publicKey);
            foreach(str_split($data, 117) as $chunk)
            {
                openssl_public_encrypt($chunk, $encrypted, $res);
                $crypto .= $encrypted;
            }
            
            return base64_encode($crypto);
        } catch (Exception $e) {
            return;
        }
    }
    
    /**
     * 私钥解密
     * @param $data
     * @param $privateKey
     * @return string|$decrypto
     */
    static function privateDecrypt($data, $privateKey)
    {
        $decrypto = "";
        $res = openssl_pkey_get_private($privateKey);
        foreach (str_split(base64_decode($data), 128) as $chunk)
        {
            openssl_private_decrypt($chunk, $decrypted, $res);
            $decrypto .= $decrypted;
        }
            
        return $decrypto;
    }

    /**
     * curl post请求
     *
     * @param
     *            $url
     * @param
     *            $data
     * @return
     *
     */
    static function curlPost($url, $data)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json'
        ));
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $tmpInfo = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        return $tmpInfo;
    }
    
    /**
     * 获取IP
     * @return string|ip
     */
    static function getIp()
    {
        $ip = "";
        if(getenv('HTTP_CLIENT_IP')) {
            $ip = getenv('HTTP_CLIENT_IP');
        } elseif(getenv('HTTP_X_FORWARDED_FOR')) {
            $ip = getenv('HTTP_X_FORWARDED_FOR');
        } elseif(getenv('REMOTE_ADDR')) {
            $ip = getenv('REMOTE_ADDR');
        } else {
            $ip = $HTTP_SERVER_VARS['REMOTE_ADDR'];
        }
        
        return $ip;
    }
    
    /**
     * 获取毫秒时间戳
     * @return number
     */
    function msectime() {
        list($msec, $sec) = explode(' ', microtime());
        $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
        return $msectime;
    }
    
}
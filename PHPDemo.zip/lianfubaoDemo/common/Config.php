<?php
class Config {
    // 版本号，固定值1.1
    const version = 1.1;
    
    // 商户编号
    const merId = 1000002;
    
    // 支付下单请求地址
    const payUrl = "http://apidemo.lfbpay.link/api/payOrder/prepay";
    
    // 支付订单查询请求地址
    const payQueryUrl = "http://apidemo.lfbpay.link/api/payOrder/query";
    
    // 代付下单请求地址
    const remitUrl = "http://apidemo.lfbpay.link/api/remitOrder/submit";
    
    // 代付订单查询请求地址
    const remitQueryUrl = "http://apidemo.lfbpay.link/api/remitOrder/query";
    
    // 余额查询请求地址
    const balanceUrl = "http://apidemo.lfbpay.link/api/balance/query";
    
    // 支付签名的MD5密钥
    const paySignKey = "86b10f4ae2b629de5000a7e5c9b9b8eb";
    
    // 支付对接公钥
    const payPublicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCO2t2Fnhtat18dTegf5wetyr36FK1eL4U2m/y5QvxhfUkH8/SSseZ5Sq39RG7T2Zk6kfZL2Bfg+yEm336F4Zdth3TUCJAriHm/1YsQSfSTg4niP2hrE/JGZ7HMAHXS5qOxFmq3u4GVmcShTgjLLeRg6kZ3dO9Pi/ybDkx/Aso92QIDAQAB";
    
    // 支付对接私钥
    const payPrivateKey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAI5vK8zu7kJDom8OPcHdPLtmjvRh7PWyD/fME6ofRxWg7U5ExEjUjdhqLuMkkfls9YG1DGKvVp+NoT6HVoCEcFT3DLYLbqE2DCwx5c0/wAssW8nqQISyfIX5iAjeGBLLUBo1Rf3m4AxUvCT/jKUYu0VG8weceQTpee1sxyZqMC6bAgMBAAECgYAYAtW3bm/r68ruPdBbZhhe3yMqP3fa03GtrFGEVFF/a+mVUDJmtK5U1VGiKQAStDOO8h5sZHKN4ypTiC0k7S6iY5vJ5aj8H2WD9u6LVlm0UpqXG9yYEnYt7c3ksBz7/EAgldWYJ7UscEsQzNpCnXsLBHIWclTlZVlC95G84pADgQJBAMxZgz0btAbketMsV4ITEC3R6JlatQoQOyOlzT2GTgqr0bYNZEPB3asxrNpcRdWrNnrbai1NVr0WzI8zhbZsThkCQQCyb2jmufPZShgmIKj5zhmqlwB+mVirnWg3rAvY4k+RdjLbBdrD/aVcEQZUBHN5PvIThyR3/bbVenpho3dzJFDTAkABIcHLVdryatOPVeCKNObTCiWaq9jy3FIniWSQoazO/FKmCn7yrSE4MIc/kmFEpLUhixOUeqgvVe/+Hw/vibwJAkBEPlnnjI0XuL/drTYTPGESnmgBA1MnZ69ZQ4LQc1WtM4ClxepydQsOWDCMZ5tmbs2U7GXlQnLv2MT/nM5tiiEjAkEAyHChzBSvWZJ2YsfDfV3sAdTJV1yhDm4DOteelJgNwBABVfzrmAASM5XvGIz/ETHFkpTtIbLS3YoP9i6qCUfsOg==";
    
    // 代付签名的MD5密钥
    const remitSignKey = "4c8f659133b2069707be6161894dd0f0";
    
    // 代付对接公钥
    const remitPublicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCnUqKPqIjBALutgLNjAiidu/UoYo8xVNI3V0Cgcu3LNa2uHWlRWc9Rh5Yueaadkwv9qC3PQAk3YpkOTfPvfQHZLXJH4wlHE00XugopDYmCzUnrkexTNoJH53paG66jDigmc6nIxDKuyduF04Zj2R/54y+q5zGP+79lHbhCTOBZewIDAQAB";
    
    // 代付对接私钥
    const remitPrivateKey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBALOtlvh/WSeiRuhbtjhgtKKaK1PKDeH3WKIBwi9Fd5DdFRW399QyiFTApoJMkaBe/sdk9vYNwkJFrDqC9ZQP+XPzsr9JOYOwsxNT/zSONSFsNiEUMf223eNLzS3Caw6Okljn051hdMsccPsjFmTqOcLjJKUXFdWOU2fouioDsAaHAgMBAAECgYBDuquuAFMbHZCdBfUqS0nMAVFTxFZ3V0WRzBfmucjYUn4gMbi5xFKfn/8kHrjGOwjPIL/3ADi5womphLQNm/frmZW3F2gFT6ESgOoBSX0KE8wXcYivTCjP3JSJzSYkAfIAcuXuddxCey34W9GqBbMFhINxXLkOolO85exM9ZdAAQJBAPyTY3hZ58HgoJ3S3DI1AaJV63x1j7PCxnMP9p/tq2DxZ+NaUl4/OkFattRv2QSi/UbhgvYAVe7KlvB6EFng+sECQQC2HTI6qkEoyXj91hrParLY5mS0lZ+JfPpNwCI53l7Il6G2eu/dS4f9vDL2VuaDy7ZxuUpAeoVO7fbWqa/cgDtHAkBHwqh0PTb3gpafwJUHPsAkGz04sz4M2L4BWvu7HI+gj3Xwxmy4kkY+40MmwFBsXNKRHOlUc2v22GBiGowivSUBAkEAnvMysROC1ceri9oBAoJ9YWUOBrQFUCo+Cfilpt6Y2fnG0o/QpdTT+Dn4PRwyDFyUfAQec9K8Ydy/MjNe5FUj5wJAKeR56Oa22dXrOX+dRWmSFgs+Z1DsE/3xfT1yvdF9TPhuFog1596b/AXpnViynYoRPCoRX+zgNyD01Nf/s3YAQQ==";
    
}
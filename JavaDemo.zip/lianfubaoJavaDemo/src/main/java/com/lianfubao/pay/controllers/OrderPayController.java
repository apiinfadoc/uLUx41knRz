package com.lianfubao.pay.controllers;

import com.alibaba.fastjson.JSONObject;
import com.lianfubao.pay.utils.HttpHelper;
import com.lianfubao.pay.utils.RSACoder;
import com.lianfubao.pay.vo.CallbackDataVO;
import com.lianfubao.pay.vo.PayOrderQueryVO;
import com.lianfubao.pay.vo.PrepayOrderVO;
import com.lianfubao.pay.vo.RemitOrderSubmitVO;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

@Controller
@RequestMapping("api")
public class OrderPayController {


    public static final String REQ_DOMAIN = "http://apidemo.lfbpay.link";

    /**商户分配ID*/
    public static final String MERID = "1000002";

    /**固定版本号*/
    public static final String VERSION = "1.1";

    // ---------------------阿里测试环境------------------------------
    /**支付商户分配公钥*/
    public static final String PAY_PUBLICK_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCO2t2Fnhtat18dTegf5wetyr36FK1eL4U2m/y5QvxhfUkH8/SSseZ5Sq39RG7T2Zk6kfZL2Bfg+yEm336F4Zdth3TUCJAriHm/1YsQSfSTg4niP2hrE/JGZ7HMAHXS5qOxFmq3u4GVmcShTgjLLeRg6kZ3dO9Pi/ybDkx/Aso92QIDAQAB";

    /**支付商户分配私钥*/
    public static final String PAY_PRIVATE_KEY = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAI5vK8zu7kJDom8OPcHdPLtmjvRh7PWyD/fME6ofRxWg7U5ExEjUjdhqLuMkkfls9YG1DGKvVp+NoT6HVoCEcFT3DLYLbqE2DCwx5c0/wAssW8nqQISyfIX5iAjeGBLLUBo1Rf3m4AxUvCT/jKUYu0VG8weceQTpee1sxyZqMC6bAgMBAAECgYAYAtW3bm/r68ruPdBbZhhe3yMqP3fa03GtrFGEVFF/a+mVUDJmtK5U1VGiKQAStDOO8h5sZHKN4ypTiC0k7S6iY5vJ5aj8H2WD9u6LVlm0UpqXG9yYEnYt7c3ksBz7/EAgldWYJ7UscEsQzNpCnXsLBHIWclTlZVlC95G84pADgQJBAMxZgz0btAbketMsV4ITEC3R6JlatQoQOyOlzT2GTgqr0bYNZEPB3asxrNpcRdWrNnrbai1NVr0WzI8zhbZsThkCQQCyb2jmufPZShgmIKj5zhmqlwB+mVirnWg3rAvY4k+RdjLbBdrD/aVcEQZUBHN5PvIThyR3/bbVenpho3dzJFDTAkABIcHLVdryatOPVeCKNObTCiWaq9jy3FIniWSQoazO/FKmCn7yrSE4MIc/kmFEpLUhixOUeqgvVe/+Hw/vibwJAkBEPlnnjI0XuL/drTYTPGESnmgBA1MnZ69ZQ4LQc1WtM4ClxepydQsOWDCMZ5tmbs2U7GXlQnLv2MT/nM5tiiEjAkEAyHChzBSvWZJ2YsfDfV3sAdTJV1yhDm4DOteelJgNwBABVfzrmAASM5XvGIz/ETHFkpTtIbLS3YoP9i6qCUfsOg==";

    /**支付商户分配签名秘钥*/
    public static final String PAY_SING_KEY = "86b10f4ae2b629de5000a7e5c9b9b8eb";

    /**代付商户分配公钥*/
    public static final String REMIT_PUBLICK_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCnUqKPqIjBALutgLNjAiidu/UoYo8xVNI3V0Cgcu3LNa2uHWlRWc9Rh5Yueaadkwv9qC3PQAk3YpkOTfPvfQHZLXJH4wlHE00XugopDYmCzUnrkexTNoJH53paG66jDigmc6nIxDKuyduF04Zj2R/54y+q5zGP+79lHbhCTOBZewIDAQAB";

    /**代付商户分配私钥*/
    public static final String REMIT_PRIVATE_KEY = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBALOtlvh/WSeiRuhbtjhgtKKaK1PKDeH3WKIBwi9Fd5DdFRW399QyiFTApoJMkaBe/sdk9vYNwkJFrDqC9ZQP+XPzsr9JOYOwsxNT/zSONSFsNiEUMf223eNLzS3Caw6Okljn051hdMsccPsjFmTqOcLjJKUXFdWOU2fouioDsAaHAgMBAAECgYBDuquuAFMbHZCdBfUqS0nMAVFTxFZ3V0WRzBfmucjYUn4gMbi5xFKfn/8kHrjGOwjPIL/3ADi5womphLQNm/frmZW3F2gFT6ESgOoBSX0KE8wXcYivTCjP3JSJzSYkAfIAcuXuddxCey34W9GqBbMFhINxXLkOolO85exM9ZdAAQJBAPyTY3hZ58HgoJ3S3DI1AaJV63x1j7PCxnMP9p/tq2DxZ+NaUl4/OkFattRv2QSi/UbhgvYAVe7KlvB6EFng+sECQQC2HTI6qkEoyXj91hrParLY5mS0lZ+JfPpNwCI53l7Il6G2eu/dS4f9vDL2VuaDy7ZxuUpAeoVO7fbWqa/cgDtHAkBHwqh0PTb3gpafwJUHPsAkGz04sz4M2L4BWvu7HI+gj3Xwxmy4kkY+40MmwFBsXNKRHOlUc2v22GBiGowivSUBAkEAnvMysROC1ceri9oBAoJ9YWUOBrQFUCo+Cfilpt6Y2fnG0o/QpdTT+Dn4PRwyDFyUfAQec9K8Ydy/MjNe5FUj5wJAKeR56Oa22dXrOX+dRWmSFgs+Z1DsE/3xfT1yvdF9TPhuFog1596b/AXpnViynYoRPCoRX+zgNyD01Nf/s3YAQQ==";

    /**代付商户分配签名秘钥*/
    public static final String REMIT_SING_KEY = "4c8f659133b2069707be6161894dd0f0";


    @PostMapping("prepay")
    @ResponseBody
    public JSONObject prepay(PrepayOrderVO prepayOrderVO) throws Exception {

        SortedMap<String,Object> bodyMap = new TreeMap<>();
        bodyMap.put("merOrderNo",prepayOrderVO.getMerOrderNo());
        bodyMap.put("amount",prepayOrderVO.getAmount());
        bodyMap.put("payType",prepayOrderVO.getPayType());
        bodyMap.put("notifyUrl",prepayOrderVO.getNotifyUrl());
        bodyMap.put("expireTime",prepayOrderVO.getExpireTime());
        bodyMap.put("bankCode",prepayOrderVO.getBankCode());
        bodyMap.put("orderIp",prepayOrderVO.getOrderIp());
        bodyMap.put("submitTime",System.currentTimeMillis());
        bodyMap.put("businessType",1);

        // 生成签名信息
        String signStr = mapToString(bodyMap) + "&key=" + PAY_SING_KEY;
        String sign = DigestUtils.md5Hex(signStr);
        bodyMap.put("sign",sign);
        bodyMap.put("returnViewUrl",prepayOrderVO.getReturnViewUrl());
        bodyMap.put("remarks",prepayOrderVO.getRemarks());


        // 使用非对称加密加密此dataMap
        String data = RSACoder.encryptByPublicKey(JSONObject.toJSONString(bodyMap), PAY_PUBLICK_KEY);

        // 封装请求协议
        Map<String,Object> dataMap = new HashMap<>();
        dataMap.put("merId", MERID);
        dataMap.put("version", VERSION);
        dataMap.put("data",data);

        String redirectUrl = null;
        // 提交预下单请求
        String res = HttpHelper.post(REQ_DOMAIN+"/api/payOrder/prepay",JSONObject.toJSONString(dataMap));
        JSONObject resJSON = JSONObject.parseObject(res);
        if(StringUtils.isNotEmpty(res)){
            if(resJSON.getInteger("code").intValue() == 200){
                redirectUrl = resJSON.getString("payUrl");
            }
        }
        return resJSON;
    }


    @PostMapping("remitSubmit")
    @ResponseBody
    public JSONObject remitSubmit(RemitOrderSubmitVO remitOrderSubmitVO) throws Exception {

        SortedMap<String,Object> bodyMap = new TreeMap<>();
        bodyMap.put("merOrderNo",remitOrderSubmitVO.getMerOrderNo());
        bodyMap.put("amount",remitOrderSubmitVO.getAmount());
        bodyMap.put("notifyUrl",remitOrderSubmitVO.getNotifyUrl());
        bodyMap.put("bankCode",remitOrderSubmitVO.getBankCode());
        bodyMap.put("submitTime",System.currentTimeMillis());
        bodyMap.put("bankAccountNo",remitOrderSubmitVO.getBankAccountNo());
        bodyMap.put("bankAccountName",remitOrderSubmitVO.getBankAccountName());


        // 生成签名信息
        String signStr = mapToString(bodyMap) + "&key=" + REMIT_SING_KEY;
        String sign = DigestUtils.md5Hex(signStr);
        bodyMap.put("sign",sign);
        bodyMap.put("bankBranchName",remitOrderSubmitVO.getBankBranchName());
        bodyMap.put("remarks",remitOrderSubmitVO.getRemarks());

        // 使用非对称加密加密此dataMap
        String data = RSACoder.encryptByPublicKey(JSONObject.toJSONString(bodyMap), REMIT_PUBLICK_KEY);

        // 封装请求协议
        Map<String,Object> dataMap = new HashMap<>();
        dataMap.put("merId", MERID);
        dataMap.put("version", VERSION);
        dataMap.put("data",data);

        // 提交预下单请求
        JSONObject resJSON = null;
        String res = HttpHelper.post(REQ_DOMAIN+"/api/remitOrder/submit",JSONObject.toJSONString(dataMap));
        if(StringUtils.isNotEmpty(res)){
            resJSON = JSONObject.parseObject(res);
            if(resJSON.getInteger("code").intValue() == 200){
                System.out.println("代付订单提交成功");
            }
        }
        return resJSON;
    }


    @PostMapping("payOrderQuery")
    @ResponseBody
    public JSONObject payOrderQuery(PayOrderQueryVO payOrderQueryVO) throws Exception {
        SortedMap<String,Object> bodyMap = new TreeMap<>();
        bodyMap.put("merOrderNo",payOrderQueryVO.getMerOrderNo());
        // TODO 这里的submitTime以订单实际的提交时间戳为准。
        bodyMap.put("submitTime",System.currentTimeMillis());

        // 生成签名信息
        String signStr = mapToString(bodyMap) + "&key=" + PAY_SING_KEY;
        String sign = DigestUtils.md5Hex(signStr);
        bodyMap.put("sign",sign);


        // 使用非对称加密加密此dataMap
        String data = RSACoder.encryptByPublicKey(JSONObject.toJSONString(bodyMap), PAY_PUBLICK_KEY);

        // 封装请求协议
        Map<String,Object> dataMap = new HashMap<>();
        dataMap.put("merId", MERID);
        dataMap.put("version", VERSION);
        dataMap.put("data",data);

        String res = HttpHelper.post(REQ_DOMAIN+"/api/payOrder/query",JSONObject.toJSONString(dataMap));
        // 如果响应成功,则对响应进行验证签名
        JSONObject resJSON = JSONObject.parseObject(res);
        if(resJSON.getInteger("code").intValue() == 200){

            SortedMap<String,Object> resParaMap = new TreeMap<>();
            resParaMap.put("merId",resJSON.getString("merId"));
            resParaMap.put("merOrderNo",resJSON.getString("merOrderNo"));
            resParaMap.put("orderState",resJSON.getIntValue("orderState"));
            resParaMap.put("orderNo",resJSON.getIntValue("orderNo"));
            resParaMap.put("amount",resJSON.getBigDecimal("amount"));


            String resSign = mapToString(resParaMap) + "&key=" + PAY_SING_KEY;
            // 验证响应签名
            if(DigestUtils.md5Hex(resSign).equalsIgnoreCase(resJSON.getString("sign"))){
                return resJSON;
            }
        }
        return resJSON;
    }

    @PostMapping("remitOrderQuery")
    @ResponseBody
    public JSONObject remitOrderQuery(PayOrderQueryVO payOrderQueryVO) throws Exception {

        SortedMap<String,Object> bodyMap = new TreeMap<>();
        bodyMap.put("merOrderNo",payOrderQueryVO.getMerOrderNo());
        // TODO 这里的submitTime以订单实际的提交时间戳为准。
        bodyMap.put("submitTime",System.currentTimeMillis());

        // 生成签名信息
        String signStr = mapToString(bodyMap) + "&key=" + REMIT_SING_KEY;
        String sign = DigestUtils.md5Hex(signStr);
        bodyMap.put("sign",sign);

        // 使用非对称加密加密此dataMap
        String data = RSACoder.encryptByPublicKey(JSONObject.toJSONString(bodyMap), REMIT_PUBLICK_KEY);

        // 封装请求协议
        Map<String,Object> dataMap = new HashMap<>();
        dataMap.put("merId", MERID);
        dataMap.put("version", VERSION);
        dataMap.put("data",data);

        String res = HttpHelper.post(REQ_DOMAIN+"/api/remitOrder/query",JSONObject.toJSONString(dataMap));

        // 如果响应成功,则对响应进行验证签名
        JSONObject resJSON = JSONObject.parseObject(res);
        if(resJSON.getInteger("code").intValue() == 200){

            SortedMap<String,Object> resParaMap = new TreeMap<>();
            resParaMap.put("merId",resJSON.getString("merId"));
            resParaMap.put("merOrderNo",resJSON.getString("merOrderNo"));
            resParaMap.put("orderState",resJSON.getIntValue("orderState"));
            resParaMap.put("orderNo",resJSON.getIntValue("orderNo"));
            resParaMap.put("amount",resJSON.getBigDecimal("amount"));


            String resSign = mapToString(resParaMap) + "&key=" + REMIT_SING_KEY;
            // 验证响应签名
            if(DigestUtils.md5Hex(resSign).equalsIgnoreCase(resJSON.getString("sign"))){
                return resJSON;
            }
        }
        return resJSON;
    }


    @RequestMapping("payOrderCallback")
    @ResponseBody
    public String payOrderCallback(@RequestBody CallbackDataVO dataVO) throws Exception {

        // 根据商户私钥解密协议体
        String data = RSACoder.decryptByPrivateKey(dataVO.getData(),PAY_PRIVATE_KEY);
        JSONObject dataJSON = JSONObject.parseObject(data);

        // 解密后对签名验证
        SortedMap<String,Object> bodyMap = new TreeMap<>();
        bodyMap.put("merOrderNo",dataJSON.getString("merOrderNo"));
        bodyMap.put("orderState",dataJSON.getInteger("orderState"));
        bodyMap.put("orderNo",dataJSON.getString("orderNo"));
        bodyMap.put("amount",dataJSON.getBigDecimal("amount"));


        String sign = DigestUtils.md5Hex(mapToString(bodyMap) + "&key=" + PAY_SING_KEY);
        if(sign.equalsIgnoreCase(dataJSON.getString("sign"))){
            // 对支付回调进行业务处理
            return "success";
        }
        return "fail";
    }


    @RequestMapping("remitOrderCallback")
    @ResponseBody
    public String remitOrderCallback(@RequestBody CallbackDataVO dataVO) throws Exception {
        // 根据商户私钥解密协议体
        String data = RSACoder.decryptByPrivateKey(dataVO.getData(),REMIT_PRIVATE_KEY);
        JSONObject dataJSON = JSONObject.parseObject(data);

        // 解密后对签名验证
        SortedMap<String,Object> bodyMap = new TreeMap<>();
        bodyMap.put("merOrderNo",dataJSON.getString("merOrderNo"));
        bodyMap.put("orderState",dataJSON.getInteger("orderState"));
        bodyMap.put("orderNo",dataJSON.getString("orderNo"));
        bodyMap.put("amount",dataJSON.getBigDecimal("amount"));


        String sign = DigestUtils.md5Hex(mapToString(bodyMap) + "&key=" + REMIT_SING_KEY);
        if(sign.equalsIgnoreCase(dataJSON.getString("sign"))){
            // 对支付回调进行业务处理
            return "success";
        }
        return "fail";
    }

    private static String mapToString(Map<String, Object> dataMap) {
        StringBuilder sb = new StringBuilder();
        dataMap.forEach((k, v) -> sb.append(k).append("=").append(v).append("&"));
        return sb.substring(0, sb.length() - 1);
    }

    public static void main(String[] args) throws Exception {

        //{"amount":"1","bankAccountName":"范德萨","bankAccountNo":"6222024301000000000","bankCode":"CZB","merOrderNo":"21910002","notifyUrl":"http://a.com/onlinePay/ReplaceNotify/hengxin.do","sign":"9884C48E102FA9CE5727AFCD1B9A0A75","submitTime":"1558603120356"}
        // {"merOrderNo":"20190617030831650","amount":"10.00","submitTime":1560756191421,"notifyUrl":"http://pay.bge999.net/dev/e2575a5ba054910ad5c98ade99b223a3e10bc9914d2eb030","bankCode":"CEB","bankAccountNo":"312312312312312312","bankAccountName":"测试h","sign":"BD189DAB5B77B0DDB6E76BE3E9D6A9C5"}

        //dataJson:{"bankAccountName":"测试h","bankCode":"CEB","amount":"10.00","submitTime":1560755337191,"merOrderNo":"20190617030831650","bankBranchName":"21321312","notifyUrl":"http://pay.bge999.net/dev/763b76b524c2d72937ff674b8d7a2612362e03b758f0b74b","bankAccountNo":"312312312312312312"}



        String merOrderNo = "20190617030831650";
        BigDecimal amount = new BigDecimal("10.00");
        String notifyUrl = "http://a.com/onlinePay/ReplaceNotify/hengxin.do";
        String bankCode = "CZB";
        String submitTime = String.valueOf(System.currentTimeMillis());
        String bankAccountNo = "6222024301000000000";
        String bankAccountName = "范德萨";

        String bankBranchName = "123123";
        String remarks = "123123";


        SortedMap<String,Object> bodyMap = new TreeMap<>();
        bodyMap.put("merOrderNo",merOrderNo);
        bodyMap.put("amount",amount);
        bodyMap.put("notifyUrl",notifyUrl);
        bodyMap.put("bankCode",bankCode);
        bodyMap.put("submitTime",submitTime);
        bodyMap.put("bankAccountNo",bankAccountNo);
        bodyMap.put("bankAccountName",bankAccountName);


        // 生成签名信息
        String signStr = mapToString(bodyMap) + "&key=" + REMIT_SING_KEY;
        System.out.println("signStr = " + signStr);
        String sign = DigestUtils.md5Hex(signStr);
        System.out.println("sign = " + sign);
        bodyMap.put("sign",sign);
        bodyMap.put("bankBranchName",bankBranchName);
        bodyMap.put("remarks",remarks);

        // 使用非对称加密加密此dataMap
        String data = RSACoder.encryptByPublicKey(JSONObject.toJSONString(bodyMap), REMIT_PUBLICK_KEY);

        System.out.println("data = " + data);
        // 封装请求协议
        Map<String,Object> dataMap = new HashMap<>();
        dataMap.put("merId", MERID);
        dataMap.put("version", VERSION);
        dataMap.put("data",data);

        // 提交预下单请求
        JSONObject resJSON = null;
        String res = HttpHelper.post(REQ_DOMAIN+"/api/remitOrder/submit",JSONObject.toJSONString(dataMap));
        System.out.println("res = " + res);

    }

}

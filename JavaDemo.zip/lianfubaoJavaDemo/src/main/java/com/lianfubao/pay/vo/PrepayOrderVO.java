package com.lianfubao.pay.vo;

import java.math.BigDecimal;

public class PrepayOrderVO {

    /**商户订单号*/
    private String merOrderNo;

    /**订单金额*/
    private BigDecimal amount;

    /**银行编码*/
    private String bankCode;

    /**支付类型*/
    private String payType;

    /**通知地址*/
    private String notifyUrl;

    /**过期时间*/
    private Integer expireTime;

    /**订单IP*/
    private String orderIp;

    /**回显地址*/
    private String returnViewUrl;

    /**备注*/
    private String remarks;

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getMerOrderNo() {
        return merOrderNo;
    }

    public void setMerOrderNo(String merOrderNo) {
        this.merOrderNo = merOrderNo;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getNotifyUrl() {
        return notifyUrl;
    }

    public void setNotifyUrl(String notifyUrl) {
        this.notifyUrl = notifyUrl;
    }

    public Integer getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(Integer expireTime) {
        this.expireTime = expireTime;
    }

    public String getOrderIp() {
        return orderIp;
    }

    public void setOrderIp(String orderIp) {
        this.orderIp = orderIp;
    }

    public String getReturnViewUrl() {
        return returnViewUrl;
    }

    public void setReturnViewUrl(String returnViewUrl) {
        this.returnViewUrl = returnViewUrl;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}

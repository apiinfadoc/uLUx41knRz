package com.lianfubao.pay.utils;

import org.apache.commons.io.IOUtils;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.SocketConfig;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultConnectionKeepAliveStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class HttpHelper {

    private static final Logger log = LoggerFactory.getLogger(HttpHelper.class);

    private static CloseableHttpClient httpClient;


    static {
        RequestConfig.Builder requestConfigBuilder = RequestConfig.custom();
        // 客户端和服务器建立连接的timeout
        requestConfigBuilder.setConnectTimeout(30000);
        // 从连接池获取连接的timeout
        requestConfigBuilder.setConnectionRequestTimeout(30000);
        // 连接建立后，request没有回应的timeout
        requestConfigBuilder.setSocketTimeout(30000);
        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
        connectionManager.setMaxTotal(200);
        connectionManager.setDefaultMaxPerRoute(20); // 同一路由最多100并发

        HttpClientBuilder clientBuilder = HttpClientBuilder.create();
        clientBuilder.setDefaultRequestConfig(requestConfigBuilder.build());
        clientBuilder.setDefaultSocketConfig(SocketConfig.custom().setSoTimeout(30000).build());
        clientBuilder.setConnectionManager(connectionManager);
        // 连接建立后，request没有回应的timeout
        clientBuilder.setKeepAliveStrategy(new DefaultConnectionKeepAliveStrategy());
        httpClient = clientBuilder.build();
    }



    public static String post(String url, String dataStr) {
        log.info("HTTP请求URL:" + url);
        log.info("HTTP请求参数:" + dataStr);
        HttpPost httpPost = new HttpPost(url);

        try {
            StringEntity entity = new StringEntity(dataStr, "utf-8");
            entity.setContentEncoding("UTF-8");
            entity.setContentType("application/json");
            httpPost.setEntity(entity);
            CloseableHttpResponse response = httpClient.execute(httpPost);
            String result = IOUtils.toString(response.getEntity().getContent(),"UTF-8");
            log.info("HTTP返回结果:" + result);
            return result;
        } catch (Exception e) {
            log.error("http error:", e);
        } finally {
            httpPost.releaseConnection();
        }
        return null;
    }


}
